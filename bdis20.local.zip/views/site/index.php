<?php

/* @var $this yii\web\View */

$this->title = 'АІС Майстерня картин';
?>


<div class="site-index">

   
    
        <p>Пройдіть <a href="login.php">аутентифікацію</a> та оберіть категорію:</p>
        <ul>
            <li><a href="/web/index.php?r=managers%2Findex">Менеджери</a></li>
            <li><a href="/web/index.php?r=designers%2Findex">Дизайнери</a></li>
            <li><a href="/web/index.php?r=pictures%2Findex">Картини</a></li>
            <li><a href="/web/index.php?r=orders%2Findex">Замовлення</a></li>
            <li><a href="/web/index.php?r=cheks%2Findex">Чеки</a></li>
            <li><a href="/web/index.php?r=clients%2Findex">Клієнти</a></li>            
            <li><a href="/web/index.php?r=phones%2Findex">Номери телефонів</a></li>
        </ul></div>  
    <div class="jumbotron">
        <br>
        <p>   НАЦІОНАЛЬНИЙ УНІВЕРСИТЕТ "КИЄВО-МОГИЛЯНСЬКА АКАДЕМІЯ"
            <br>
          
ФАКУЛЬТЕТ ІНФОРМАТИКИ
<br>
Самостійна робота з дисципліни:
<br>
«Бази даних та інформаційні системи»
<br>
Розробка АІС «Майстерня картин»
<br>
Виконав: студент - групи ---------
<br>
Викладач: ---------</p>
    </div>
</div>
